#!/bin/bash
# Runs before the new revision files are copied onto the instance.
# Installs the web server if it isn't already present and clears old content.

if ! command -v httpd &> /dev/null; then
  yum install -y httpd
fi

rm -rf /var/www/html/*
