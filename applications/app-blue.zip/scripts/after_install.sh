#!/bin/bash
# Runs after files are copied onto the instance, before the app starts.
# Sets correct ownership/permissions on the deployed content.

chown -R apache:apache /var/www/html
chmod -R 755 /var/www/html
