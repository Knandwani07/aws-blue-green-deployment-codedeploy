#!/bin/bash
# Confirms the local instance is actually serving content before
# CodeDeploy registers it with the target group / shifts traffic.

for i in {1..10}; do
  RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost/health.html)
  if [ "$RESPONSE" == "200" ]; then
    echo "Health check passed."
    exit 0
  fi
  echo "Waiting for service to become healthy... attempt $i"
  sleep 5
done

echo "Health check failed after 10 attempts."
exit 1
