#!/bin/bash
# Starts (or restarts) the web server so it picks up the new revision.

systemctl enable httpd
systemctl restart httpd
